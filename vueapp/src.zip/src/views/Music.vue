<template>
    <div>
        music
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>